import { NextResponse } from "next/server";
import path from "path";
import fs from "fs/promises";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const f = searchParams.get("f");
  if (!f) return NextResponse.json({ ok: false, error: "Missing filename" }, { status: 400 });
  if (!/^report-[\w-]+\.xlsx$/.test(f)) return NextResponse.json({ ok: false, error: "Invalid filename" }, { status: 400 });

  const filePath = path.join(process.cwd(), "outputs", f);
  const data = await fs.readFile(filePath);

  return new NextResponse(data, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="${f}"`,
    },
  });
}
